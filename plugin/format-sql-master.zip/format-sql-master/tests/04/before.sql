select     * from    y;
