def x():
    s = """ select * from x; """
