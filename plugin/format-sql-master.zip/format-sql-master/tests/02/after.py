def x():
    s = """
        SELECT
            *
        FROM
            x; """
