select     * from    x;
