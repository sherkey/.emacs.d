SELECT
    *
FROM
    x;
